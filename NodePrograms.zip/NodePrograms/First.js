﻿var express = require("express");
var bodyParser = require("body-parser");
var cache = require('memory-cache');
var app = express();

var getReqCnt = 0, postReqCnt = 0;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//Get request to send form for post request
app.get('/', function (req, res) {
    res.sendFile("/Users/newuser/Desktop/NodePrograms/Test.html");
});


//Get request that returns storedin-memory data
app.get('/sendGet', function (req, res) {
    console.log(">sendGet: received request");
    console.log("<sendGet: sending response");

    getReqCnt++;
    console.log('Processed Request Count--> sendGet: ' + getReqCnt + ', sendPost: ' + postReqCnt);

    var keyArr = cache.keys();
    var keyValues = "";
    for (var i = 0; i < keyArr.length; i++) {
        keyValues += cache.get(keyArr[i]) + "<br />";
    }
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(keyValues);
});

//Get request that deletes all stored in-memory data
app.get('/sendDelete', function (req, res) {
    cache.clear();
    res.end("Your all stored in-memory data is now cleared. Please make a check using http://127.0.0.1/sendGet");
});

//Post request to handle json payload
app.post('/sendPost', function (req, res) {
    console.log(">sendPost: received request");
    console.log("<sendPost: sending response");

    postReqCnt++;
    console.log('Processed Request Count--> sendGet: ' + getReqCnt + ', sendPost: ' + postReqCnt);

    var p_id = req.body.p_id;
    var p_name = req.body.p_name;
    var p_price = req.body.p_price;
    cache.put(p_id, 'Product Id: ' + p_id + ' Product Name: ' + p_name + ' Product Price: ' + p_price);
    res.end();
});

//Starts server at port 8080
app.listen(8080, function () {
    console.log("Server is listening at port http://127.0.0.1:8080/");
    console.log("\nEndpoints:");
    console.log("http://127.0.0.1:8080/sendGet method: GET");
    console.log("http://127.0.0.1:8080/sendPost method: POST");
    console.log("http://127.0.0.1:8080/sendDelete method: GET");
})